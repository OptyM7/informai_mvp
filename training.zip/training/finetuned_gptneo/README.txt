Download model.safetensors from link below and paste in this directory 

https://csuprod-my.sharepoint.com/:u:/g/personal/jadigu01_student_csu_edu_au/EVt3cIFdex9Fgfv2h4UoHKkBLEk5eovRC_fTy6d1Lh3CAw?e=dRUiq5

Can't upload to GitHub due to filesize